
import React from 'react';
import { formatTimeDetailed } from '../utils/formatters';

interface TimerDisplayProps {
  time: number;
}

const TimerDisplay: React.FC<TimerDisplayProps> = ({ time }) => {
  const { m, s, ms } = formatTimeDetailed(time);

  return (
    <div className="flex flex-col items-center justify-center py-12 md:py-20 relative">
      {/* Background glow decorative element */}
      <div className="absolute inset-0 bg-blue-500/10 blur-[120px] rounded-full pointer-events-none"></div>
      
      <div className="flex items-baseline mono font-bold text-7xl md:text-9xl tracking-tighter tabular-nums z-10 neon-glow">
        <span className="text-white">{m}</span>
        <span className="text-blue-500/50 mx-1 md:mx-2">:</span>
        <span className="text-white">{s}</span>
        <span className="text-blue-500 text-3xl md:text-5xl ml-2 font-medium opacity-80">.{ms}</span>
      </div>
      
      <div className="mt-4 text-gray-500 text-sm md:text-base font-medium tracking-widest uppercase opacity-50">
        Minutes : Seconds . Centiseconds
      </div>
    </div>
  );
};

export default TimerDisplay;
