
import React from 'react';

interface CountdownInputProps {
  hours: number;
  minutes: number;
  seconds: number;
  onChange: (type: 'h' | 'm' | 's', value: number) => void;
  disabled: boolean;
}

const CountdownInput: React.FC<CountdownInputProps> = ({ hours, minutes, seconds, onChange, disabled }) => {
  const InputBox = ({ value, label, max, type }: { value: number; label: string; max: number; type: 'h' | 'm' | 's' }) => (
    <div className="flex flex-col items-center gap-2">
      <input
        type="number"
        value={value}
        disabled={disabled}
        onChange={(e) => {
          let val = parseInt(e.target.value) || 0;
          if (val > max) val = max;
          if (val < 0) val = 0;
          onChange(type, val);
        }}
        className="w-20 md:w-24 h-20 md:h-24 glass rounded-2xl text-center text-3xl md:text-4xl font-black mono text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 border-white/10 transition-all disabled:opacity-30"
      />
      <span className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">{label}</span>
    </div>
  );

  return (
    <div className="flex items-center justify-center gap-4 py-8">
      <InputBox value={hours} label="Hours" max={99} type="h" />
      <span className="text-4xl text-white/20 font-light mb-6">:</span>
      <InputBox value={minutes} label="Minutes" max={59} type="m" />
      <span className="text-4xl text-white/20 font-light mb-6">:</span>
      <InputBox value={seconds} label="Seconds" max={59} type="s" />
    </div>
  );
};

export default CountdownInput;
