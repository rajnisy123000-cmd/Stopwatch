
import React, { useState, useEffect } from 'react';
import { Lap, AppMode, PomodoroPhase } from '../types';
import { analyzePerformance } from '../services/geminiService';

interface AICoachProps {
  mode: AppMode;
  laps: Lap[];
  pomodoroPhase?: PomodoroPhase;
  isRunning: boolean;
}

const AICoach: React.FC<AICoachProps> = ({ mode, laps, pomodoroPhase, isRunning }) => {
  const [analysis, setAnalysis] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const shouldAnalyze = 
      (mode === 'stopwatch' && laps.length >= 2) || 
      (mode === 'pomodoro' && isRunning) || 
      (mode === 'countdown' && isRunning);

    if (shouldAnalyze) {
      const timer = setTimeout(() => handleAnalyze(), mode === 'stopwatch' ? 100 : 5000);
      return () => clearTimeout(timer);
    }
  }, [laps.length, pomodoroPhase, isRunning, mode]);

  const handleAnalyze = async () => {
    setLoading(true);
    const result = await analyzePerformance(mode, { laps, pomodoroPhase });
    setAnalysis(result);
    setLoading(false);
  };

  if (mode === 'stopwatch' && laps.length < 2) return null;

  return (
    <div className="mt-6 glass rounded-2xl p-6 border-l-4 border-l-blue-500 shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-700">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
        <h4 className="text-xs font-bold text-blue-400 uppercase tracking-widest">Velocity AI Insight</h4>
      </div>
      <p className="text-gray-300 text-sm leading-relaxed italic">
        {loading ? (
          <span className="animate-pulse opacity-50">Syncing with performance engine...</span>
        ) : (
          `"${analysis || 'Standby for coaching data...'}"`
        )}
      </p>
    </div>
  );
};

export default AICoach;
