
import React from 'react';
import { Lap } from '../types';
import { formatTime } from '../utils/formatters';

interface LapHistoryProps {
  laps: Lap[];
}

const LapHistory: React.FC<LapHistoryProps> = ({ laps }) => {
  if (laps.length === 0) {
    return (
      <div className="mt-8 flex flex-col items-center justify-center p-12 glass rounded-3xl border-dashed border-2 border-white/5 opacity-40">
        <p className="text-gray-400 text-sm font-medium">No laps recorded yet</p>
      </div>
    );
  }

  // Find best and worst laps
  const sortedTimes = [...laps].sort((a, b) => a.time - b.time);
  const bestTime = sortedTimes[0].time;
  const worstTime = sortedTimes[sortedTimes.length - 1].time;

  return (
    <div className="mt-8 glass rounded-3xl overflow-hidden shadow-2xl transition-all duration-500 max-h-[400px] flex flex-col">
      <div className="px-6 py-4 bg-white/5 border-b border-white/10 flex justify-between items-center shrink-0">
        <h3 className="text-sm font-bold uppercase tracking-widest text-blue-400">Lap History</h3>
        <span className="text-xs text-gray-400">{laps.length} Laps Total</span>
      </div>
      <div className="overflow-y-auto custom-scrollbar flex-1">
        <table className="w-full text-left">
          <thead className="text-[10px] uppercase text-gray-500 border-b border-white/5 sticky top-0 bg-[#121212] z-10">
            <tr>
              <th className="px-6 py-3 font-medium">#</th>
              <th className="px-6 py-3 font-medium">Lap Time</th>
              <th className="px-6 py-3 font-medium">Total Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {[...laps].reverse().map((lap, index) => {
              const lapNumber = laps.length - index;
              const isBest = lap.time === bestTime && laps.length > 1;
              const isWorst = lap.time === worstTime && laps.length > 1;

              return (
                <tr key={lap.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-6 py-4 text-gray-500 text-xs font-mono">{lapNumber.toString().padStart(2, '0')}</td>
                  <td className={`px-6 py-4 font-mono font-bold text-lg ${isBest ? 'text-emerald-400' : isWorst ? 'text-rose-400' : 'text-white'}`}>
                    {formatTime(lap.time)}
                    {isBest && <span className="ml-2 text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded uppercase tracking-tighter">Fastest</span>}
                  </td>
                  <td className="px-6 py-4 text-gray-400 font-mono text-sm opacity-60">
                    {formatTime(lap.splitTime)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LapHistory;
