
import React from 'react';
import { AppMode } from '../types';

interface ModeSelectorProps {
  currentMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  disabled: boolean;
}

const ModeSelector: React.FC<ModeSelectorProps> = ({ currentMode, onModeChange, disabled }) => {
  const modes: { id: AppMode; label: string }[] = [
    { id: 'stopwatch', label: 'Stopwatch' },
    { id: 'pomodoro', label: 'Pomodoro' },
    { id: 'countdown', label: 'Countdown' },
  ];

  return (
    <div className="flex p-1 bg-white/5 rounded-2xl border border-white/10 mb-8 w-full max-w-md mx-auto relative z-20">
      {modes.map((mode) => (
        <button
          key={mode.id}
          disabled={disabled}
          onClick={() => onModeChange(mode.id)}
          className={`flex-1 py-2.5 text-xs font-bold uppercase tracking-widest rounded-xl transition-all duration-300 ${
            currentMode === mode.id
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40'
              : 'text-gray-500 hover:text-gray-300 hover:bg-white/5 disabled:opacity-30'
          }`}
        >
          {mode.label}
        </button>
      ))}
    </div>
  );
};

export default ModeSelector;
