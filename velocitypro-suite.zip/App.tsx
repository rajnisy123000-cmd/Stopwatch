
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Lap, AppMode, PomodoroPhase } from './types';
import TimerDisplay from './components/TimerDisplay';
import LapHistory from './components/LapHistory';
import AICoach from './components/AICoach';
import ModeSelector from './components/ModeSelector';
import CountdownInput from './components/CountdownInput';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>('stopwatch');
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<Lap[]>([]);
  
  // Countdown State
  const [cdHours, setCdHours] = useState(0);
  const [cdMinutes, setCdMinutes] = useState(0);
  const [cdSeconds, setCdSeconds] = useState(0);

  // Pomodoro State
  const [pomoPhase, setPomoPhase] = useState<PomodoroPhase>('work');
  const [pomoCycle, setPomoCycle] = useState(1);

  const timerRef = useRef<number | null>(null);
  const lastTickRef = useRef<number>(0);
  const lastLapTimeRef = useRef<number>(0);

  const clearTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const startStop = useCallback(() => {
    if (isRunning) {
      clearTimer();
      setIsRunning(false);
    } else {
      // Validate countdown before starting
      if (mode === 'countdown' && time <= 0) {
        const totalMs = (cdHours * 3600 + cdMinutes * 60 + cdSeconds) * 1000;
        if (totalMs <= 0) return;
        setTime(totalMs);
      }

      setIsRunning(true);
      lastTickRef.current = Date.now();
      
      timerRef.current = window.setInterval(() => {
        const now = Date.now();
        const delta = now - lastTickRef.current;
        lastTickRef.current = now;

        setTime(prev => {
          if (mode === 'stopwatch') return prev + delta;
          
          const nextTime = prev - delta;
          if (nextTime <= 0) {
            handleTimerComplete();
            return 0;
          }
          return nextTime;
        });
      }, 10);
    }
  }, [isRunning, mode, time, cdHours, cdMinutes, cdSeconds]);

  const handleTimerComplete = () => {
    clearTimer();
    setIsRunning(false);
    
    // Auto-advance Pomodoro
    if (mode === 'pomodoro') {
      if (pomoPhase === 'work') {
        if (pomoCycle % 4 === 0) {
          setPomoPhase('longBreak');
          setTime(15 * 60 * 1000);
        } else {
          setPomoPhase('shortBreak');
          setTime(5 * 60 * 1000);
        }
      } else {
        setPomoPhase('work');
        setPomoCycle(prev => prev + 1);
        setTime(25 * 60 * 1000);
      }
    }
    
    // Alert logic (Visual)
    const body = document.body;
    body.classList.add('bg-blue-900/40');
    setTimeout(() => body.classList.remove('bg-blue-900/40'), 1000);
  };

  const reset = useCallback(() => {
    clearTimer();
    setIsRunning(false);
    lastLapTimeRef.current = 0;
    
    if (mode === 'stopwatch') {
      setTime(0);
      setLaps([]);
    } else if (mode === 'pomodoro') {
      setPomoPhase('work');
      setPomoCycle(1);
      setTime(25 * 60 * 1000);
    } else if (mode === 'countdown') {
      setTime(0);
      setCdHours(0);
      setCdMinutes(0);
      setCdSeconds(0);
    }
  }, [mode]);

  const addLap = useCallback(() => {
    const lapTime = time - lastLapTimeRef.current;
    const newLap: Lap = {
      id: crypto.randomUUID(),
      time: lapTime,
      splitTime: time,
      timestamp: Date.now(),
    };
    setLaps(prev => [...prev, newLap]);
    lastLapTimeRef.current = time;
  }, [time]);

  const handleModeChange = (newMode: AppMode) => {
    clearTimer();
    setIsRunning(false);
    setMode(newMode);
    
    if (newMode === 'stopwatch') {
      setTime(0);
    } else if (newMode === 'pomodoro') {
      setPomoPhase('work');
      setTime(25 * 60 * 1000);
    } else if (newMode === 'countdown') {
      setTime(0);
    }
  };

  const handleCdChange = (type: 'h' | 'm' | 's', val: number) => {
    if (type === 'h') setCdHours(val);
    if (type === 'm') setCdMinutes(val);
    if (type === 's') setCdSeconds(val);
    
    // Dynamically update display time if not running
    if (!isRunning) {
      const h = type === 'h' ? val : cdHours;
      const m = type === 'm' ? val : cdMinutes;
      const s = type === 's' ? val : cdSeconds;
      setTime((h * 3600 + m * 60 + s) * 1000);
    }
  };

  useEffect(() => {
    return () => clearTimer();
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center bg-[#0a0a0a] px-4 py-8 md:py-12 selection:bg-blue-500/30 transition-colors duration-1000">
      <div className="w-full max-w-2xl flex flex-col">
        
        <header className="flex justify-between items-center mb-10 px-2">
          <div className="flex flex-col">
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tighter text-white">
              VELOCITY<span className="text-blue-500">PRO</span>
            </h1>
            <p className="text-[10px] uppercase tracking-widest text-gray-500 font-semibold">Precision Suite v2.0</p>
          </div>
          <div className="flex flex-col items-end">
            <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-all duration-300 ${isRunning ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 'bg-gray-800 text-gray-500'}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-blue-400 animate-pulse' : 'bg-gray-600'}`}></span>
              {isRunning ? (mode === 'pomodoro' ? `${pomoPhase}` : 'Running') : 'Idle'}
            </div>
            {mode === 'pomodoro' && (
              <span className="text-[10px] text-gray-600 font-bold mt-1 uppercase tracking-tighter">Cycle {pomoCycle}</span>
            )}
          </div>
        </header>

        <ModeSelector 
          currentMode={mode} 
          onModeChange={handleModeChange} 
          disabled={isRunning}
        />

        {mode === 'countdown' && !isRunning && time === 0 ? (
          <CountdownInput 
            hours={cdHours} 
            minutes={cdMinutes} 
            seconds={cdSeconds} 
            onChange={handleCdChange} 
            disabled={isRunning}
          />
        ) : (
          <TimerDisplay time={time} />
        )}

        <div className="flex flex-wrap items-center justify-center gap-4 mt-4">
          <button
            onClick={reset}
            disabled={time === 0 && !isRunning && mode !== 'pomodoro'}
            className="group relative px-8 py-4 rounded-full bg-white/5 border border-white/10 text-gray-400 font-bold text-sm uppercase tracking-widest transition-all hover:bg-white/10 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
          >
            Reset
          </button>

          <button
            onClick={startStop}
            className={`group relative px-12 py-5 rounded-full font-black text-lg uppercase tracking-[0.2em] transition-all duration-300 transform active:scale-95 shadow-2xl ${
              isRunning 
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/40' 
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/40'
            }`}
          >
            <span className="relative z-10">{isRunning ? 'Stop' : 'Start'}</span>
            <div className={`absolute inset-0 rounded-full blur-xl opacity-50 transition-all group-hover:opacity-100 ${isRunning ? 'bg-rose-500' : 'bg-blue-500'}`}></div>
          </button>

          {mode === 'stopwatch' && (
            <button
              onClick={addLap}
              disabled={!isRunning}
              className="group relative px-8 py-4 rounded-full bg-white/5 border border-white/10 text-gray-400 font-bold text-sm uppercase tracking-widest transition-all hover:bg-white/10 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
            >
              Lap
            </button>
          )}
        </div>

        <AICoach 
          mode={mode} 
          laps={laps} 
          pomodoroPhase={mode === 'pomodoro' ? pomoPhase : undefined} 
          isRunning={isRunning} 
        />

        {mode === 'stopwatch' && <LapHistory laps={laps} />}
        
        {mode === 'pomodoro' && (
          <div className="mt-8 glass rounded-3xl p-8 flex flex-col items-center justify-center text-center animate-in fade-in zoom-in duration-500">
            <h3 className="text-xl font-bold text-white mb-2 uppercase tracking-tighter">
              {pomoPhase === 'work' ? 'Deep Work Session' : 'Rest & Recovery'}
            </h3>
            <p className="text-gray-500 text-sm max-w-sm">
              {pomoPhase === 'work' 
                ? 'Eliminate distractions. This is a high-output phase for your most complex tasks.' 
                : 'Step away from the screen. Let your brain consolidate information and refresh.'}
            </p>
            <div className="flex gap-2 mt-6">
              {[1, 2, 3, 4].map(step => (
                <div 
                  key={step} 
                  className={`h-1.5 w-12 rounded-full transition-all duration-500 ${step <= (pomoCycle % 4 || 4) ? 'bg-blue-500' : 'bg-white/10'}`}
                ></div>
              ))}
            </div>
          </div>
        )}

        <footer className="mt-12 mb-8 text-center text-gray-600 text-[10px] font-medium uppercase tracking-[0.3em] opacity-40">
          Professional Grade Time Management Suite
        </footer>
      </div>
    </div>
  );
};

export default App;
