
import { GoogleGenAI } from "@google/genai";
import { Lap, AppMode, PomodoroPhase } from "../types";

export const analyzePerformance = async (
  mode: AppMode, 
  data: { laps?: Lap[], pomodoroPhase?: PomodoroPhase, countdownTarget?: number }
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let prompt = "";

  if (mode === 'stopwatch' && data.laps && data.laps.length > 0) {
    const lapData = data.laps.map((l, i) => `Lap ${i + 1}: ${l.time}ms`).join(', ');
    prompt = `Analyze these stopwatch lap times: ${lapData}. Provide a short (max 2 sentences), punchy, motivational performance summary. No markdown.`;
  } else if (mode === 'pomodoro') {
    prompt = `The user is in a ${data.pomodoroPhase} phase of a Pomodoro cycle. Give a one-sentence, highly focused tip for productivity or recovery based on this phase. No markdown.`;
  } else if (mode === 'countdown') {
    prompt = `The user is using a countdown timer for a task. Provide a one-sentence tip on maintaining deep focus until the timer ends. No markdown.`;
  } else {
    return "Ready to track your performance.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.7,
        maxOutputTokens: 100,
      }
    });
    return response.text || "Keep pushing your limits!";
  } catch (error) {
    return "Great effort! Stay focused on your goals.";
  }
};
