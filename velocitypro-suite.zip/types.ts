
export type AppMode = 'stopwatch' | 'pomodoro' | 'countdown';

export type PomodoroPhase = 'work' | 'shortBreak' | 'longBreak';

export interface Lap {
  id: string;
  time: number;
  splitTime: number;
  timestamp: number;
}

export interface AIAnalysis {
  summary: string;
  suggestion: string;
  consistencyScore: number;
}
